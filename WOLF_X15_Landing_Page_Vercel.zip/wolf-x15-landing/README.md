# WOLF X15 Landing Page

Website statis satu halaman, responsif untuk HP dan desktop. Siap di-deploy ke Vercel.

## Sebelum dipublikasikan
1. Buka `index.html`.
2. Cari `const WHATSAPP_ADMIN = "628XXXXXXXXXX";`
3. Ganti `628XXXXXXXXXX` dengan nomor WhatsApp admin dalam format internasional tanpa tanda `+`, spasi, atau strip. Contoh format: `6281234567890`.
4. Simpan perubahan.

## Deploy ke Vercel
1. Buat akun / login ke https://vercel.com/
2. Simpan folder proyek ini ke GitHub sebagai repository baru (misalnya `wolf-x15-landing`).
3. Di Vercel pilih **Add New → Project**, lalu import repository GitHub tersebut.
4. Framework preset: **Other**. Build Command dan Output Directory dikosongkan; Root Directory gunakan `./`.
5. Klik **Deploy**. Vercel akan memberikan URL website.
6. Untuk domain sendiri, buka Project → Settings → Domains.

## Catatan
- Monitoring di halaman ini adalah PREVIEW/ilustrasi, bukan data akun real atau hasil trading.
- Harga membership sengaja belum dicantumkan.
- Tombol WhatsApp belum siap dipakai sampai nomor admin diganti.
- Ini landing page informasi dan pendaftaran manual; belum ada login, database, atau pembayaran otomatis.
